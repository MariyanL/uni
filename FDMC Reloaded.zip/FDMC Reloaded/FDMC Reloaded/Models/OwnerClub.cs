﻿namespace FDMC_Reloaded.Models
{
    public class OwnerClub
    {
        public int OwnerId { get; set; }
        public virtual Owner? Owner { get; set; }
        public int ClubId { get; set; }
        public virtual Club? Club { get; set; }
    }
}
