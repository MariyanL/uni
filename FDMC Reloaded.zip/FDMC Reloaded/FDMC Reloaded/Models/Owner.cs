﻿namespace FDMC_Reloaded.Models
{
    public class Owner
    {
        public int Id { get; set; }
        public string? Name { get; set; }
        public string? City { get; set; }
        public virtual Cat? Cat { get; set; }
        public virtual ICollection<OwnerClub>? OwnerClubs { get; set; }
    }
}
