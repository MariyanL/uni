﻿using FDMC_Reloaded.Models;
using Microsoft.EntityFrameworkCore;

namespace FDMC_Reloaded.Data
{
    public class AppDbContext : DbContext
    {
        public virtual DbSet<Cat> Cats { get; set; }
        public virtual DbSet<Breed> Breeds { get; set; }
        public virtual DbSet<Owner> Owners { get; set; }
        public virtual DbSet<Club> Clubs { get; set; }
        public virtual DbSet<OwnerClub> OwnerClubs { get; set; }

        public AppDbContext()
        {

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<OwnerClub>()
                .HasKey(oc => new { oc.OwnerId, oc.ClubId });

            modelBuilder.Entity<Cat>()
                .HasOne(c => c.Breed)
                .WithMany(b => b.Cats)
                .HasForeignKey(c => c.BreedId);

            modelBuilder.Entity<Cat>()
                .HasOne(c => c.Owner)
                .WithOne(c => c.Cat)
                .HasForeignKey<Cat>(c => c.OwnerId);

            modelBuilder.Entity<OwnerClub>()
                .HasOne(oc => oc.Owner)
                .WithMany(oc => oc.OwnerClubs)
                .HasForeignKey(oc => oc.ClubId);


            modelBuilder.Entity<OwnerClub>()
                .HasOne(oc => oc.Club)
                .WithMany(oc => oc.OwnerClubs)
                .HasForeignKey(oc => oc.ClubId);
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            base.OnConfiguring(optionsBuilder);
            optionsBuilder.UseLazyLoadingProxies();
            optionsBuilder.UseSqlServer("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=FDMCR;Integrated Security=True;Connect Timeout=30;");
        }
    }
}
